 Computational Statistics Toolbox.
 Version 1.0 (R12)     26-Sep-2001

 For more information on these functions, their theoretical foundation
   and references, please refer to the book 
   
   'Computational Statistics Handbook with MATLAB' by
   Wendy Martinez and Angel Martinez, CRC Press, Sep 2001.
   
 For more information on these functions, type helpwin
   at the command line and select this toolbox.
   
 These M-files are provided on an 'as is' basis, without any express or
    implied warranty. The authors, publisher and distributors do not 
    guarantee their accuracy and are not responsible for any damages
    arising from the use of these M-files.
       
 See the website: http://www.infinityassociates.com/ 
    for the latest versions and bug fixes.
       
 The authors are willing to respond to problems regarding these functions.
    Please report any bugs, suggestions, etc. to:
    wmartinez@infinityassociates.com
    
 